﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace PR19
{
    class Zavod
    {
       
            private string name;
            private int powerunit;
            private string fulnamedir;
            private string adress;
            private int create;
            public Zavod(string name, int powerunit, string fulnamedir, string adress, int create)
            {
                this.name = name;
                this.powerunit = powerunit;
                this.fulnamedir = fulnamedir;
                this.adress = adress;
                this.create = create;
            }
            public Zavod()
            {
                name = "PleshinaGame";
                powerunit = 5;
                fulnamedir = "Ленусик Ивановна Сергеевна";
                adress = "Высоцкого 34";
                create = 2004;
            }
            ~Zavod()
            {

                MessageBox.Show($"Завод {name} уничтожен");
            }

            public override string ToString ()
            {
                return String.Format($"Название предприятия: {name} | кол-во рабочей силы: {powerunit} | имя директора {fulnamedir} | адреса {adress} | Год создания {create}");
            }
            public void setpowerunit(int p)
            {
                if (p > 50)
                    MessageBox.Show("Кол-во работников мб не больше 50");
                else
                {
                    powerunit = p;
                }
            }
            public void setfulnamedir(string d)
            {

                if (d.Length > 25)
                {
                    MessageBox.Show("ФИО не мб таким длинным ");

                }
                else
                {
                    fulnamedir = d;
                }

            }
            public void setadres( string h)
            {
               if  (h.Length < 20)
                {
                   
                    adress = h;

                }

                else if (h.Length > 20)

                {
                    MessageBox.Show("Превышена длина адреса");
                }

            }
        public void setName(string g)
        {
            if (g.Length < 15) 
            {
                name = g;
            }
        }
        public void SetCreate(int J)
        {
            if (J > 2022)
            {
                MessageBox.Show("Такой год не существет ");

            }
            else
            {
                create = J;
            }
        }
        public void File()
        {
            string s = name + " |" + powerunit + " |" + fulnamedir + " |" + adress + " |" + create;
            StreamWriter sw;
            FileInfo file = new FileInfo("Предприятия.txt");
            sw = file.AppendText();
            sw.WriteLine(s);
            sw.Close();
        }
        public string Vozr(string s)
        {
            return s = name + " |" + powerunit + " |" + fulnamedir + " |" + adress + " |" + create;
        }



    }
    class mepublic : Zavod
        {
            public int Numberlets;
            public mepublic(string name, int powerunit, string fulnamedir, string adress, int create, int n)
            : base(name, powerunit, fulnamedir, adress, create)
            {
                Numberlets = n;
            }
            public mepublic()
            : base()
            {
                Numberlets = 921;
            }
            public void setNum(int j)
            {
                if (j > 1000)
                {
                    MessageBox.Show("Такой лицензии не существует");
                }
                else
                {
                    Numberlets = j;
                }

            }
        }



    }


