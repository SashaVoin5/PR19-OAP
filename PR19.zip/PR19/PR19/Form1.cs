﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Добавлено:");
            string name = textBox1.Text;
            int powerunit = Convert.ToInt32(textBox2.Text);
            string fulnamedir = textBox3.Text, adress = textBox4.Text;
            int create = Convert.ToInt32(textBox5.Text);

            Zavod t = new Zavod(name, powerunit, fulnamedir, adress, create);
            t.File();
            listBox1.Items.Add(t.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileStream file = new FileStream("Предприятия.txt", FileMode.Create);
            file.Close();
            listBox1.Items.Add("Файл создан");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string path = "Предприятия.txt";
            string[] readText = File.ReadAllLines(path, Encoding.UTF8);
            listBox1.Items.Add("ОТСОРТИРОВАННЫЙ СПИСОК(По имени):");
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string path = "Предприятия.txt";
            string[] readText = File.ReadAllLines(path, Encoding.UTF8);
            listBox1.Items.Add("ОТСОРТИРОВАННЫЙ СПИСОК(По году):");
            


        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int number = Convert.ToInt32(textBox6.Text);
            if ((number != 0) && (number > 0))
            {
                string path = "Предприятия.txt";
                List<string> fileContent = new List<string>();
                fileContent.AddRange(File.ReadAllLines(path));
                if (fileContent.Count >= number)
                {
                    for (int i = 0; i < fileContent.Count; i++)
                    {
                        if (i == (number - 1))
                        {
                            string[] s = fileContent[i].Split(new char[] { '|', ' ' },
                                        StringSplitOptions.RemoveEmptyEntries);
                            string n1 = s[0];
                            int rn1 = Convert.ToInt32(s[1]);
                            string ms1 = s[2];
                            string qc1 = s[3];
                            int qr1 = Convert.ToInt32(s[4]);
                            Zavod t = new Zavod(n1, rn1, ms1, qc1, qr1);
                            if (textBox7.Text != "")
                            {
                                string n = (textBox7.Text);
                                t.setName(n);
                            }
                            if (textBox8.Text != "")
                            {
                                int n = Convert.ToInt32(textBox8.Text);
                                t.setpowerunit(n);
                            }

                            if (textBox9.Text != "")
                            {
                                string n = (textBox9.Text);
                                t.setfulnamedir(n);
                            }
                            if (textBox10.Text != "")
                            {
                                string n = (textBox10.Text);
                                t.setadres(n);
                            }
                            if (textBox11.Text != "")
                            {
                                int n = Convert.ToInt32(textBox11.Text);
                                t.SetCreate(n);
                            }



                            string line = "";
                            fileContent[i] = t.Vozr(line);
                        }
                    }
                }
                File.WriteAllLines(path, fileContent);
                string[] readText = File.ReadAllLines(path, Encoding.UTF8);
                listBox1.Items.Add("РЕЗУЛЬТАТ:");
                for (int i = 0; i < readText.Length; i++)
                {
                    string[] s = readText[i].Split(new char[] { '|', ' ' },
                                        StringSplitOptions.RemoveEmptyEntries);
                    string n = s[0];
                    int rn = Convert.ToInt32(s[1]);
                    string ms = s[2];
                    string qc = s[3];
                    int qr = Convert.ToInt32(s[4]);
                    Zavod t = new Zavod(n, rn, ms, qc, qr);
                    listBox1.Items.Add("Файл изменен");
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox1.Items.Add("РЕЗУЛЬТАТ ПОИСКА:");
            
            
        }
    }
}







