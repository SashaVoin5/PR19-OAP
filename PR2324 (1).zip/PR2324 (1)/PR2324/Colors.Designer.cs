﻿
namespace PR2324
{
    partial class Colors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Blue = new System.Windows.Forms.Label();
            this.lb_Green = new System.Windows.Forms.Label();
            this.lb_Red = new System.Windows.Forms.Label();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Ok = new System.Windows.Forms.Button();
            this.numeric_Blue = new System.Windows.Forms.NumericUpDown();
            this.numeric_Green = new System.Windows.Forms.NumericUpDown();
            this.numeric_Red = new System.Windows.Forms.NumericUpDown();
            this.Scroll_Blue = new System.Windows.Forms.HScrollBar();
            this.Scroll_Green = new System.Windows.Forms.HScrollBar();
            this.Scroll_Red = new System.Windows.Forms.HScrollBar();
            this.btn_OtherColors = new System.Windows.Forms.Button();
            this.picResultColor = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_Blue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_Green)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_Red)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picResultColor)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_Blue
            // 
            this.lb_Blue.AutoSize = true;
            this.lb_Blue.Location = new System.Drawing.Point(29, 146);
            this.lb_Blue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_Blue.Name = "lb_Blue";
            this.lb_Blue.Size = new System.Drawing.Size(43, 23);
            this.lb_Blue.TabIndex = 11;
            this.lb_Blue.Text = "Blue";
            // 
            // lb_Green
            // 
            this.lb_Green.AutoSize = true;
            this.lb_Green.Location = new System.Drawing.Point(29, 86);
            this.lb_Green.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_Green.Name = "lb_Green";
            this.lb_Green.Size = new System.Drawing.Size(56, 23);
            this.lb_Green.TabIndex = 10;
            this.lb_Green.Text = "Green";
            // 
            // lb_Red
            // 
            this.lb_Red.AutoSize = true;
            this.lb_Red.Location = new System.Drawing.Point(29, 26);
            this.lb_Red.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_Red.Name = "lb_Red";
            this.lb_Red.Size = new System.Drawing.Size(39, 23);
            this.lb_Red.TabIndex = 9;
            this.lb_Red.Text = "Red";
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(151, 195);
            this.btn_Cancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(112, 41);
            this.btn_Cancel.TabIndex = 19;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            // 
            // btn_Ok
            // 
            this.btn_Ok.Location = new System.Drawing.Point(29, 195);
            this.btn_Ok.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Ok.Name = "btn_Ok";
            this.btn_Ok.Size = new System.Drawing.Size(112, 41);
            this.btn_Ok.TabIndex = 18;
            this.btn_Ok.Text = "Ok";
            this.btn_Ok.UseVisualStyleBackColor = true;
            this.btn_Ok.Click += new System.EventHandler(this.btn_Ok_Click);
            // 
            // numeric_Blue
            // 
            this.numeric_Blue.InterceptArrowKeys = false;
            this.numeric_Blue.Location = new System.Drawing.Point(412, 147);
            this.numeric_Blue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numeric_Blue.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numeric_Blue.Name = "numeric_Blue";
            this.numeric_Blue.Size = new System.Drawing.Size(69, 30);
            this.numeric_Blue.TabIndex = 17;
            this.numeric_Blue.ValueChanged += new System.EventHandler(this.numeric_Blue_ValueChanged_1);
            // 
            // numeric_Green
            // 
            this.numeric_Green.InterceptArrowKeys = false;
            this.numeric_Green.Location = new System.Drawing.Point(412, 86);
            this.numeric_Green.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numeric_Green.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numeric_Green.Name = "numeric_Green";
            this.numeric_Green.Size = new System.Drawing.Size(69, 30);
            this.numeric_Green.TabIndex = 16;
            this.numeric_Green.ValueChanged += new System.EventHandler(this.numeric_Green_ValueChanged_1);
            // 
            // numeric_Red
            // 
            this.numeric_Red.InterceptArrowKeys = false;
            this.numeric_Red.Location = new System.Drawing.Point(412, 26);
            this.numeric_Red.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numeric_Red.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numeric_Red.Name = "numeric_Red";
            this.numeric_Red.Size = new System.Drawing.Size(69, 30);
            this.numeric_Red.TabIndex = 15;
            this.numeric_Red.ValueChanged += new System.EventHandler(this.numeric_Red_ValueChanged_1);
            // 
            // Scroll_Blue
            // 
            this.Scroll_Blue.LargeChange = 1;
            this.Scroll_Blue.Location = new System.Drawing.Point(126, 152);
            this.Scroll_Blue.Maximum = 255;
            this.Scroll_Blue.Name = "Scroll_Blue";
            this.Scroll_Blue.Size = new System.Drawing.Size(266, 17);
            this.Scroll_Blue.TabIndex = 14;
            this.Scroll_Blue.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Scroll_Blue_Scroll_1);
            // 
            // Scroll_Green
            // 
            this.Scroll_Green.LargeChange = 1;
            this.Scroll_Green.Location = new System.Drawing.Point(126, 92);
            this.Scroll_Green.Maximum = 255;
            this.Scroll_Green.Name = "Scroll_Green";
            this.Scroll_Green.Size = new System.Drawing.Size(266, 17);
            this.Scroll_Green.TabIndex = 13;
            this.Scroll_Green.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Scroll_Green_Scroll);
            // 
            // Scroll_Red
            // 
            this.Scroll_Red.LargeChange = 1;
            this.Scroll_Red.Location = new System.Drawing.Point(126, 32);
            this.Scroll_Red.Maximum = 255;
            this.Scroll_Red.Name = "Scroll_Red";
            this.Scroll_Red.Size = new System.Drawing.Size(266, 17);
            this.Scroll_Red.TabIndex = 12;
            this.Scroll_Red.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Scroll_Red_Scroll);
            // 
            // btn_OtherColors
            // 
            this.btn_OtherColors.Location = new System.Drawing.Point(516, 194);
            this.btn_OtherColors.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_OtherColors.Name = "btn_OtherColors";
            this.btn_OtherColors.Size = new System.Drawing.Size(112, 41);
            this.btn_OtherColors.TabIndex = 21;
            this.btn_OtherColors.Text = "Other colors";
            this.btn_OtherColors.UseVisualStyleBackColor = true;
            this.btn_OtherColors.Click += new System.EventHandler(this.btn_OtherColors_Click_1);
            // 
            // picResultColor
            // 
            this.picResultColor.Location = new System.Drawing.Point(516, 13);
            this.picResultColor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.picResultColor.Name = "picResultColor";
            this.picResultColor.Size = new System.Drawing.Size(200, 156);
            this.picResultColor.TabIndex = 20;
            this.picResultColor.TabStop = false;
            this.picResultColor.Click += new System.EventHandler(this.picResultColor_Click);
            // 
            // Colors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 244);
            this.Controls.Add(this.btn_OtherColors);
            this.Controls.Add(this.picResultColor);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_Ok);
            this.Controls.Add(this.numeric_Blue);
            this.Controls.Add(this.numeric_Green);
            this.Controls.Add(this.numeric_Red);
            this.Controls.Add(this.Scroll_Blue);
            this.Controls.Add(this.Scroll_Green);
            this.Controls.Add(this.Scroll_Red);
            this.Controls.Add(this.lb_Blue);
            this.Controls.Add(this.lb_Green);
            this.Controls.Add(this.lb_Red);
            this.Name = "Colors";
            this.Text = "Colors";
            ((System.ComponentModel.ISupportInitialize)(this.numeric_Blue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_Green)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_Red)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picResultColor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Blue;
        private System.Windows.Forms.Label lb_Green;
        private System.Windows.Forms.Label lb_Red;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Ok;
        private System.Windows.Forms.NumericUpDown numeric_Blue;
        private System.Windows.Forms.NumericUpDown numeric_Green;
        private System.Windows.Forms.NumericUpDown numeric_Red;
        private System.Windows.Forms.HScrollBar Scroll_Blue;
        private System.Windows.Forms.HScrollBar Scroll_Green;
        private System.Windows.Forms.HScrollBar Scroll_Red;
        private System.Windows.Forms.Button btn_OtherColors;
        private System.Windows.Forms.PictureBox picResultColor;
    }
}